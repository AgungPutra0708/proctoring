@extends('layouts.app')

@section('content')
    <section id="hero" class="d-flex align-items-center">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 d-flex flex-column justify-content-center pt-4 pt-lg-0 order-2 order-lg-1"
                    data-aos="fade-up" data-aos-delay="200">
                    <h1>Better Solutions For Your Business</h1>
                    <h2>
                        Manage your test with Proctoring
                    </h2>
                </div>
                <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
                    <img src="{{ asset('img/hero-img.png') }}" class="img-fluid animated" alt="" />
                </div>
            </div>
        </div>
    </section>
    <!-- End Hero -->
    <main id="main">
        <!-- ======= About Section ======= -->
        <section id="about" class="why-us section-bg">
            <div class="container" data-aos="fade-up">
                <div class="section-title">
                    <h2>About Us</h2>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-1 text-center">
                        <p>
                            Proctoring system adalah sistem yang digunakan untuk memantau dan memastikan integritas selama
                            ujian atau tes. Tujuan utamanya adalah untuk mencegah kecurangan dan memastikan bahwa peserta
                            ujian mengikuti aturan yang telah ditetapkan.
                        </p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-5 align-items-stretch align-content-center" data-aos="zoom-in" data-aos-delay="150">
                        <img src="{{ asset('img/why-us.png') }}" class="img-fluid" alt="" />
                    </div>
                    <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch order-2 order-lg-1">
                        <div class="content">
                            <h4>
                                Ada beberapa jenis proctoring system, termasuk :
                            </h4>
                        </div>

                        <div class="accordion-list">
                            <ul>
                                <li>
                                    <a data-bs-toggle="collapse" class="collapse" data-bs-target="#accordion-list-1">
                                        <span>01</span> Proctoring Manual
                                        <i class="bx bx-chevron-down icon-show"></i>
                                        <i class="bx bx-chevron-up icon-close"></i>
                                    </a>
                                    <div id="accordion-list-1" class="collapse show" data-bs-parent=".accordion-list">
                                        <p>
                                            Di sini, pengawas ujian secara fisik berada di ruang ujian untuk mengawasi
                                            peserta. Ini bisa berupa pengawas yang berjalan di sekitar ruang ujian atau
                                            duduk di meja pengawas.
                                        </p>
                                    </div>
                                </li>

                                <li>
                                    <a data-bs-toggle="collapse" data-bs-target="#accordion-list-2" class="collapsed">
                                        <span>02</span> Proctoring Online (Virtual)
                                        <i class="bx bx-chevron-down icon-show"></i>
                                        <i class="bx bx-chevron-up icon-close"></i>
                                    </a>
                                    <div id="accordion-list-2" class="collapse" data-bs-parent=".accordion-list">
                                        <p>
                                            Dalam konteks ujian online, proctoring bisa
                                            dilakukan melalui perangkat lunak yang memantau peserta melalui kamera dan
                                            mikrofon komputer mereka. Sistem ini bisa mendeteksi aktivitas mencurigakan,
                                            seperti mencari jawaban di luar layar ujian.
                                        </p>
                                    </div>
                                </li>

                                <li>
                                    <a data-bs-toggle="collapse" data-bs-target="#accordion-list-3" class="collapsed">
                                        <span>03</span> Proctoring Berbasis AI
                                        <i class="bx bx-chevron-down icon-show"></i>
                                        <i class="bx bx-chevron-up icon-close"></i>
                                    </a>
                                    <div id="accordion-list-3" class="collapse" data-bs-parent=".accordion-list">
                                        <p>
                                            Sistem ini menggunakan kecerdasan buatan untuk menganalisis perilaku peserta
                                            ujian, seperti gerakan mata atau pola keyboard,
                                            untuk mendeteksi kecurangan.
                                        </p>
                                    </div>
                                </li>

                                <li>
                                    <a data-bs-toggle="collapse" data-bs-target="#accordion-list-4" class="collapsed">
                                        <span>04</span> Proctoring dengan Keamanan Jaringan
                                        <i class="bx bx-chevron-down icon-show"></i>
                                        <i class="bx bx-chevron-up icon-close"></i>
                                    </a>
                                    <div id="accordion-list-4" class="collapse" data-bs-parent=".accordion-list">
                                        <p>
                                            Beberapa sistem memantau aktivitas di jaringan untuk mendeteksi upaya-upaya
                                            mencurigakan untuk mengakses informasi
                                            ujian secara tidak sah.
                                        </p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row text-center">
                    <p>
                        Penggunaan sistem proctoring bertujuan untuk menjaga keadilan dan validitas ujian dengan
                        mengurangi kemungkinan adanya kecurangan.
                    </p>
                    <p>
                        “IniPRODUCT merupakan sebuah sistem proctoing model hibrida yang mengkombinasikan
                        remote proctoring dimana pengawas yang dibantu oleh AI akan melakukan pengawasan
                        ujian online secara remote dalam batas waktu tertentu.”
                    </p>
                    <p>
                        Adapun sistem akan memberi notifikasi kepada pengawas dengan sistem managemnt
                        inciden yang terintegrasi dengan proctoring iniPROCUT sehingga penawas akan dapat
                        merespon dengan cepat untuk dilakukan penindakan dengan segera
                    </p>
                </div>
            </div>
        </section>
        <!-- End About Section -->

        <!-- ======= Study Case Section ======= -->
        <section id="case" class="services section-bg">
            <div class="container" data-aos="fade-up">
                <div class="section-title">
                    <h2>Studi case</h2>
                </div>

                <div class="row text-center align-center">
                    <div class="col-xl-6 col-md-6 mt-4" data-aos="zoom-in" data-aos-delay="100">
                        <div class="icon-box">
                            <div class="icon"><i class="bx bxl-dribbble"></i></div>
                            <h4><a href="">Dunia Pendidikan</a></h4>
                        </div>
                    </div>

                    <div class="col-xl-6 col-md-6 mt-4" data-aos="zoom-in" data-aos-delay="200">
                        <div class="icon-box">
                            <div class="icon"><i class="bx bx-file"></i></div>
                            <h4><a href="">Industri Keuangan</a></h4>
                        </div>
                    </div>
                </div>

                <div class="row text-center align-center">
                    <div class="col-xl-6 col-md-6 mt-4" data-aos="zoom-in" data-aos-delay="300">
                        <div class="icon-box">
                            <div class="icon"><i class="bx bx-tachometer"></i></div>
                            <h4><a href="">Asesmen Psikometri Online</a></h4>
                        </div>
                    </div>

                    <div class="col-xl-6 col-md-6 mt-4" data-aos="zoom-in" data-aos-delay="400">
                        <div class="icon-box">
                            <div class="icon"><i class="bx bx-layer"></i></div>
                            <h4><a href="">Penerimaan Karyawan Perusahaan</a></h4>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Study Case Section -->

        <!-- ======= Features Section ======= -->
        <section id="features" class="team section-bg">
            <div class="container" data-aos="fade-up">
                <div class="section-title">
                    <h2>Features</h2>
                </div>

                <div class="row">
                    <div class="col-lg-6" data-aos="zoom-in" data-aos-delay="100">
                        <div class="member d-flex align-items-start">
                            <div class="member-info">
                                <h4>Incident Management</h4>
                                <ul>
                                    <li>
                                        Mencatat hal-hal yang mecurigakan secara otomatis apabila sistem melihat
                                        suatu yang dianggap perlu diperhatikan.
                                    </li>
                                    <li>
                                        Temuan disimpan dalam bentuk cam capture dan screen capture.
                                    </li>
                                    <li>
                                        Browser not perform (browser tertutup suatu aplikasi lain)
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 mt-4 mt-lg-0" data-aos="zoom-in" data-aos-delay="200">
                        <div class="member d-flex align-items-start">
                            <div class="member-info">
                                <h4>AI Proctoring</h4>
                                <ul>
                                    <li>
                                        Gesture wajah yang mencurigakan.
                                    </li>
                                    <li>
                                        Pengenalan wajah.
                                    </li>
                                    <li>
                                        Deteksi jumlah orang yang sedang online.
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 mt-4" data-aos="zoom-in" data-aos-delay="300">
                        <div class="member d-flex align-items-start">
                            <div class="member-info">
                                <h4>Live Proctoring</h4>
                                <ul>
                                    <li>
                                        Penyediaan halaman untuk menampilkan secara langsung peserta yang
                                        sedang ujian.
                                    </li>
                                    <li>
                                        Notifikasi untuk menyapa target peserta yang dimaksud.
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 mt-4" data-aos="zoom-in" data-aos-delay="400">
                        <div class="member d-flex align-items-start">
                            <div class="member-info">
                                <h4>Activity record</h4>
                                <ul>
                                    <li>
                                        Perekaman aktifitas berdasarkan tangkapan webcam.
                                    </li>
                                    <li>
                                        Perekaman aktifitas dari browser peserta.
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 mt-4" data-aos="zoom-in" data-aos-delay="400">
                        <div class="member d-flex align-items-start">
                            <div class="member-info">
                                <h4>Browser cheat detection</h4>
                                <ul>
                                    <li>
                                        System akan mencatat apabila browser soal ujian tidak sedang berada di top
                                        layar.
                                    </li>
                                    <li>
                                        System akan mencatat apabila browser tidak berada pada tab terdepan.
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Features Section -->
        <!-- ======= Pricing Section ======= -->
        <section id="pricelist" class="pricing">
            <div class="container" data-aos="fade-up">
                <div class="section-title">
                    <h2>Pricelist</h2>
                </div>

                <div class="row">
                    <div class="col-lg-3 mt-2" data-aos="fade-up" data-aos-delay="100">
                        <div class="box">
                            <h3>Free Group</h3>
                            <h4><sup>IDR</sup>0</h4>
                            <ul>
                                <li>
                                    <i class="bx bx-check"></i> 1 Room
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Hingga 8 peserta
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Hingga 1 pengawas
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Waktu pelaksanaan 90 menit
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Reporting : Summary
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Project active retention 3 minggu
                                </li>
                            </ul>
                            <a href="#" class="buy-btn">Get Started</a>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2" data-aos="fade-up" data-aos-delay="100">
                        <div class="box">
                            <h3>Unschedule Individual</h3>
                            <h4><sup>IDR</sup>100.000</h4>
                            <ul>
                                <li>
                                    <i class="bx bx-check"></i> 1 Room
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Hingga 12 peserta
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Waktu bebas tentukan pelaksaan peserta
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> AI proctoring*
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Browser activity recording
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Webcam activity recording
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Reporting : Summary/Individual
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Project active retention 10 hari
                                </li>
                            </ul>
                            <a href="#" class="buy-btn">Get Started</a>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2" data-aos="fade-up" data-aos-delay="100">
                        <div class="box">
                            <h3>Small Group</h3>
                            <h4><sup>IDR</sup>350.000</h4>
                            <ul>
                                <li>
                                    <i class="bx bx-check"></i> 5 Room
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Hingga 35 peserta
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Hingga 5 pengawas
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Support AI proctoring
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Incident notification system
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Chatbox individual
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Chatbox Group
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Reporting : Summary/Individual
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Project active retention 30 hari
                                </li>
                            </ul>
                            <a href="#" class="buy-btn">Get Started</a>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-2" data-aos="fade-up" data-aos-delay="100">
                        <div class="box">
                            <h3>Big Event</h3>
                            <h4>Call</h4>
                            <ul>
                                <li>
                                    <i class="bx bx-check"></i> Hingga 500 peserta
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Hingga 50 pengawas
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Support AI proctoring
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Incident notification system
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Chatbox individual
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Chatbox Group
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Reporting : Summary/Individual
                                </li>
                                <li>
                                    <i class="bx bx-check"></i> Project active retention 90 hari
                                </li>
                            </ul>
                            <a href="#" class="buy-btn">Get Started</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Pricing Section -->


        <!-- ======= Syarat Section ======= -->
        <section id="term" class="term section-bg">
            <div class="container" data-aos="fade-up">
                <div class="section-title">
                    <h2>Syarat & Kondisi</h2>
                    <p>
                        Kebijakan Privasi :
                    </p>
                    <p>
                        Selamat datang di website Proctor.Web.ID
                    </p>
                    <p>
                        Kebijakan ini mengatur penggunaan dan akses Anda ke platform kami. Dengan menggunakan
                        aplikasi ini, Anda dianggap telah membaca, memahami, dan menyetujui semua ketentuan
                        yang tercantum di bawah ini. Jika Anda tidak setuju dengan kebijakan ini, harap berhenti
                        menggunakan website/aplikasi kami.
                    </p>
                </div>
            </div>
        </section>
        <!-- End Syarat Section -->

        <!-- ======= Akses dan Penggunaan Section ======= -->
        <section id="akses" class="faq section-bg">
            <div class="container" data-aos="fade-up">
                <div class="section-title">
                    <h2>Akses dan Penggunaan</h2>
                </div>
                <div class="faq-list">
                    <ul>
                        <li data-aos="fade-up" data-aos-delay="100">
                            <a data-bs-toggle="collapse" class="collapse" data-bs-target="#faq-list-1">Peserta
                                <i class="bx bx-chevron-down icon-show"></i>
                                <i class="bx bx-chevron-up icon-close"></i>
                            </a>
                            <div id="faq-list-1" class="collapse show" data-bs-parent=".faq-list">
                                <p>
                                    Untuk mengakses teknologi proctoring kami, Anda harus mendaftar sebagai peserta pada
                                    penyelenggara yang terdaftar di dalam system. dengan mengikuti proses pendaftaran yang
                                    ditentukan. Informasi yang Anda berikan harus akurat, lengkap, dan terkini.
                                </p>
                            </div>
                        </li>

                        <li data-aos="fade-up" data-aos-delay="200">
                            <a data-bs-toggle="collapse" data-bs-target="#faq-list-2" class="collapse">Penggunaan yang
                                Sah
                                <i class="bx bx-chevron-down icon-show"></i>
                                <i class="bx bx-chevron-up icon-close"></i>
                            </a>
                            <div id="faq-list-2" class="collapse show" data-bs-parent=".faq-list">
                                <p>
                                    Anda diperbolehkan menggunakan website ini untuk tujuan pribadi, non-komersial, dan
                                    sesuai dengan hukum yang berlaku. Dilarang menggunakan website/aplikasi kami untuk
                                    tujuan yang melanggar hukum, merugikan orang lain, atau melanggar hak kekayaan
                                    intelektual
                                </p>
                            </div>
                        </li>

                        <li data-aos="fade-up" data-aos-delay="300">
                            <a data-bs-toggle="collapse" data-bs-target="#faq-list-3" class="collapse">Ketersediaan
                                Layanan
                                <i class="bx bx-chevron-down icon-show"></i>
                                <i class="bx bx-chevron-up icon-close"></i>
                            </a>
                            <div id="faq-list-3" class="collapse show" data-bs-parent=".faq-list">
                                <p>
                                    Kami berupaya menjaga ketersediaan dan keandalan website kami. Namun, terkadang
                                    mungkin terjadi gangguan teknis atau pemeliharaan yang dapat memengaruhi aksesibilitas
                                    situs. Kami tidak bertanggung jawab atas kerugian atau gangguan yang disebabkan oleh
                                    ketidaktersediaan sementara.
                                </p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        <!-- End Akses dan Penggunaan Section -->
        <!-- ======= Contact Section ======= -->
        <section id="contact" class="contact">
            <div class="container" data-aos="fade-up">
                <div class="section-title">
                    <h2>Contact</h2>
                </div>

                <div class="row">
                    <div class="col-lg-5 d-flex align-items-stretch">
                        <div class="info">
                            <div class="address">
                                <i class="bi bi-geo-alt"></i>
                                <h4>Location:</h4>
                                <p>Indonesia</p>
                            </div>

                            <div class="email">
                                <i class="bi bi-envelope"></i>
                                <h4>Email:</h4>
                                <p>info@example.com</p>
                            </div>

                            <div class="phone">
                                <i class="bi bi-phone"></i>
                                <h4>Call:</h4>
                                <p>+62 888 1234 4321</p>
                            </div>

                            <iframe
                                src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621"
                                frameborder="0" style="border: 0; width: 100%; height: 290px" allowfullscreen></iframe>
                        </div>
                    </div>

                    <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
                        <form action="forms/contact.php" method="post" role="form" class="php-email-form">
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="name">Your Name</label>
                                    <input type="text" name="name" class="form-control" id="name" required />
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="name">Your Email</label>
                                    <input type="email" class="form-control" name="email" id="email" required />
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="name">Subject</label>
                                <input type="text" class="form-control" name="subject" id="subject" required />
                            </div>
                            <div class="form-group">
                                <label for="name">Message</label>
                                <textarea class="form-control" name="message" rows="10" required></textarea>
                            </div>
                            <div class="my-3">
                                <div class="loading">Loading</div>
                                <div class="error-message"></div>
                                <div class="sent-message">
                                    Your message has been sent. Thank you!
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit">Send Message</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Contact Section -->
    </main>
@endsection
